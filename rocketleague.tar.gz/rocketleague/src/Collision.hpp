#pragma once
#include <SFML/System/Vector2.hpp>
#include "Math.hpp"
#include <cmath>

// Circle vs Circle collision
struct CircleCollision {
    bool   hit;
    sf::Vector2f normal;  // from b to a
    float  depth;
};

inline CircleCollision circleVsCircle(sf::Vector2f aPos, float aR,
                                       sf::Vector2f bPos, float bR)
{
    sf::Vector2f delta = aPos - bPos;
    float dist  = Math::length(delta);
    float sumR  = aR + bR;
    if (dist < sumR && dist > 0.0001f) {
        return {true, delta / dist, sumR - dist};
    }
    return {false, {}, 0.f};
}

// Resolve ball vs car collision
// Returns impulse applied to ball
inline sf::Vector2f resolveBallCar(sf::Vector2f& ballPos, sf::Vector2f& ballVel, float ballR,
                                    sf::Vector2f carPos, sf::Vector2f& carVel, float carW, float carH,
                                    float carAngle)
{
    // Treat car as a circle for simplicity (approximation)
    float carR = (carW + carH) * 0.28f;
    auto col = circleVsCircle(ballPos, ballR, carPos, carR);
    if (!col.hit) return {0.f, 0.f};

    // Separate
    ballPos += col.normal * col.depth;

    // Relative velocity
    sf::Vector2f relVel = ballVel - carVel;
    float vn = Math::dot(relVel, col.normal);

    if (vn > 0.f) return {0.f, 0.f};  // Already separating

    // Restitution
    float restitution = 0.65f;
    float j = -(1.f + restitution) * vn;

    // Mass ratio: car is much heavier
    float ballMass = 1.f, carMass = 3.f;
    float totalMass = ballMass + carMass;
    j /= (1.f / ballMass + 1.f / carMass);

    sf::Vector2f impulse = col.normal * j;

    // Apply
    ballVel += impulse / ballMass;

    // Add some of car velocity to ball
    sf::Vector2f carDir = Math::fromAngleDeg(carAngle);
    float carSpd = Math::dot(carVel, carDir);
    if (carSpd > 50.f) {
        ballVel += carDir * carSpd * 0.3f;
    }

    return impulse;
}
