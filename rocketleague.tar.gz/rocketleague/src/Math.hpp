#pragma once
#include <SFML/System/Vector2.hpp>
#include <cmath>
#include <algorithm>

namespace Math {

inline float lengthSq(sf::Vector2f v) { return v.x*v.x + v.y*v.y; }
inline float length(sf::Vector2f v)   { return std::sqrt(lengthSq(v)); }

inline sf::Vector2f normalize(sf::Vector2f v) {
    float l = length(v);
    if (l < 1e-6f) return {0.f, 0.f};
    return {v.x / l, v.y / l};
}

inline float dot(sf::Vector2f a, sf::Vector2f b) { return a.x*b.x + a.y*b.y; }

inline sf::Vector2f fromAngleDeg(float deg) {
    float rad = deg * 3.14159265f / 180.f;
    return {std::cos(rad), std::sin(rad)};
}

inline float clamp(float v, float lo, float hi) {
    return std::max(lo, std::min(hi, v));
}

inline float lerpF(float a, float b, float t) {
    return a + (b - a) * t;
}

} // namespace Math
