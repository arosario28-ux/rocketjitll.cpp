#pragma once
#include <SFML/Graphics.hpp>
#include "Constants.hpp"
#include <string>
#include <cmath>
#include <sstream>
#include <iomanip>

// Draw a neon-style panel rectangle
inline void drawPanel(sf::RenderTarget& rt, float x, float y, float w, float h,
                      sf::Color fill = Colors::UIPanel, sf::Color border = Colors::UIBorder,
                      float thick = 2.f) {
    sf::RectangleShape panel({w, h});
    panel.setPosition(x, y);
    panel.setFillColor(fill);
    panel.setOutlineColor(border);
    panel.setOutlineThickness(thick);
    rt.draw(panel);
}

inline std::string formatTime(float seconds) {
    int s = static_cast<int>(std::ceil(seconds));
    if (s < 0) s = 0;
    int min = s / 60;
    int sec = s % 60;
    std::ostringstream oss;
    oss << min << ":" << std::setw(2) << std::setfill('0') << sec;
    return oss.str();
}

class HUD {
public:
    HUD(const sf::Font& font) : m_font(font) {}

    void draw(sf::RenderTarget& rt, int scoreLeft, int scoreRight,
              float timeLeft, float boostP1, float boostP2,
              bool camBall, const std::string& goalMsg, float goalFlash,
              bool overtime, float time) const
    {
        drawScoreTimer(rt, scoreLeft, scoreRight, timeLeft, overtime, time);
        drawBoostMeters(rt, boostP1, boostP2);
        drawCamHint(rt, camBall);
        if (goalFlash > 0.f) drawGoalSplash(rt, goalMsg, goalFlash);
        drawFieldLabels(rt);
    }

private:
    const sf::Font& m_font;

    void drawScoreTimer(sf::RenderTarget& rt, int sl, int sr, float t, bool ot, float time) const {
        // Central score panel
        float pw = 200.f, ph = 48.f;
        float px = (WINDOW_W - pw) / 2.f, py = 10.f;
        drawPanel(rt, px, py, pw, ph, Colors::UIPanel, Colors::UIBorder, 2.f);

        // Blue team score (left)
        sf::Text scoreL;
        scoreL.setFont(m_font);
        scoreL.setString(std::to_string(sl));
        scoreL.setCharacterSize(30);
        scoreL.setFillColor(Colors::NeonCyan);
        scoreL.setStyle(sf::Text::Bold);
        sf::FloatRect slb = scoreL.getLocalBounds();
        scoreL.setOrigin(slb.width, slb.height / 2.f);
        scoreL.setPosition(px + pw/2.f - 28.f, py + ph/2.f - 2.f);
        rt.draw(scoreL);

        // Orange team score (right)
        sf::Text scoreR;
        scoreR.setFont(m_font);
        scoreR.setString(std::to_string(sr));
        scoreR.setCharacterSize(30);
        scoreR.setFillColor(Colors::NeonOrange);
        scoreR.setStyle(sf::Text::Bold);
        sf::FloatRect srb = scoreR.getLocalBounds();
        scoreR.setOrigin(0.f, srb.height / 2.f);
        scoreR.setPosition(px + pw/2.f + 28.f, py + ph/2.f - 2.f);
        rt.draw(scoreR);

        // Divider
        sf::RectangleShape div({2.f, ph - 10.f});
        div.setPosition(px + pw/2.f - 1.f, py + 5.f);
        div.setFillColor(Colors::UIBorder);
        rt.draw(div);

        // Timer below score
        float tw = 100.f, th = 30.f;
        float tx = (WINDOW_W - tw) / 2.f, ty = py + ph + 4.f;
        bool urgency = t < 30.f && !ot;
        sf::Color timerBg = urgency ? sf::Color{80, 10, 10, 220} : Colors::UIPanel;
        drawPanel(rt, tx, ty, tw, th, timerBg, urgency ? sf::Color{255,50,50,200} : Colors::UIBorder, 2.f);

        sf::Text timer;
        timer.setFont(m_font);
        timer.setString(ot ? "OT" : formatTime(t));
        timer.setCharacterSize(18);
        timer.setStyle(sf::Text::Bold);
        sf::Color tCol = ot ? sf::Color{255, 100, 100, 255} : Colors::White;
        if (urgency) {
            float pulse = 0.5f + 0.5f * std::sin(time * 8.f);
            tCol = sf::Color{255, static_cast<sf::Uint8>(50 + pulse*80), static_cast<sf::Uint8>(50 + pulse*80), 255};
        }
        timer.setFillColor(tCol);
        sf::FloatRect tb = timer.getLocalBounds();
        timer.setOrigin(tb.width / 2.f, tb.height / 2.f);
        timer.setPosition(tx + tw/2.f, ty + th/2.f - 2.f);
        rt.draw(timer);
    }

    void drawBoostMeters(sf::RenderTarget& rt, float b1, float b2) const {
        // Player 1 boost (bottom-left)
        drawSingleBoost(rt, 20.f, WINDOW_H - 80.f, b1 / BOOST_MAX, "P1 BOOST", Colors::NeonCyan);
        // Player 2 boost (bottom-right)
        drawSingleBoost(rt, WINDOW_W - 170.f, WINDOW_H - 80.f, b2 / BOOST_MAX, "P2 BOOST", Colors::NeonOrange);
    }

    void drawSingleBoost(sf::RenderTarget& rt, float x, float y, float pct,
                         const std::string& label, sf::Color col) const {
        float bw = 150.f, bh = 22.f;
        drawPanel(rt, x, y, bw, bh + 24.f, Colors::UIPanel, col, 1.5f);

        // Label
        sf::Text lbl;
        lbl.setFont(m_font);
        lbl.setString(label);
        lbl.setCharacterSize(10);
        lbl.setFillColor(col);
        lbl.setPosition(x + 6.f, y + 4.f);
        rt.draw(lbl);

        // Bar bg
        sf::RectangleShape barBg({bw - 12.f, bh - 4.f});
        barBg.setPosition(x + 6.f, y + 20.f);
        barBg.setFillColor({20, 25, 50, 200});
        rt.draw(barBg);

        // Bar fill
        float fillW = (bw - 12.f) * pct;
        if (fillW > 0.f) {
            sf::RectangleShape fill({fillW, bh - 4.f});
            fill.setPosition(x + 6.f, y + 20.f);
            sf::Color fc = pct > 0.3f ? col : sf::Color{255, 60, 60, 255};
            fill.setFillColor(fc);
            rt.draw(fill);

            // Glow
            if (pct > 0.8f) {
                sf::RectangleShape glow({fillW, bh - 4.f});
                glow.setPosition(x + 6.f, y + 20.f);
                glow.setFillColor({col.r, col.g, col.b, 40});
                rt.draw(glow);
            }
        }

        // Percentage text
        sf::Text pctText;
        pctText.setFont(m_font);
        pctText.setString(std::to_string(static_cast<int>(pct * 100)) + "%");
        pctText.setCharacterSize(11);
        pctText.setFillColor(Colors::White);
        sf::FloatRect pb = pctText.getLocalBounds();
        pctText.setPosition(x + bw - pb.width - 8.f, y + 20.f + 2.f);
        rt.draw(pctText);
    }

    void drawCamHint(sf::RenderTarget& rt, bool camBall) const {
        drawPanel(rt, 10.f, 10.f, 130.f, 36.f, Colors::UIPanel, Colors::UIBorder, 1.5f);
        sf::Text cam;
        cam.setFont(m_font);
        cam.setString(camBall ? "BALL CAM" : "FREE CAM");
        cam.setCharacterSize(11);
        cam.setFillColor(camBall ? Colors::NeonCyan : Colors::NeonOrange);
        cam.setStyle(sf::Text::Bold);
        cam.setPosition(14.f, 14.f);
        rt.draw(cam);

        sf::Text hint;
        hint.setFont(m_font);
        hint.setString("C - TOGGLE");
        hint.setCharacterSize(9);
        hint.setFillColor(Colors::Gray);
        hint.setPosition(14.f, 26.f);
        rt.draw(hint);
    }

    void drawGoalSplash(sf::RenderTarget& rt, const std::string& msg, float flash) const {
        float alpha = std::min(1.f, flash / 0.3f);
        float scale = 1.f + (1.f - flash / 2.f) * 0.3f;

        // Dark overlay
        sf::RectangleShape overlay({(float)WINDOW_W, (float)WINDOW_H});
        overlay.setFillColor({0, 0, 0, static_cast<sf::Uint8>(140 * alpha)});
        rt.draw(overlay);

        sf::Text goalText;
        goalText.setFont(m_font);
        goalText.setString("GOAL!");
        goalText.setCharacterSize(static_cast<unsigned int>(90 * scale));
        goalText.setStyle(sf::Text::Bold);
        goalText.setFillColor({255, 255, 100, static_cast<sf::Uint8>(255 * alpha)});
        goalText.setOutlineColor({255, 140, 0, static_cast<sf::Uint8>(200 * alpha)});
        goalText.setOutlineThickness(4.f);
        sf::FloatRect gb = goalText.getLocalBounds();
        goalText.setOrigin(gb.width / 2.f, gb.height / 2.f);
        goalText.setPosition(WINDOW_W / 2.f, WINDOW_H / 2.f - 30.f);
        rt.draw(goalText);

        sf::Text subText;
        subText.setFont(m_font);
        subText.setString(msg);
        subText.setCharacterSize(22);
        subText.setFillColor({255, 220, 100, static_cast<sf::Uint8>(220 * alpha)});
        sf::FloatRect sb = subText.getLocalBounds();
        subText.setOrigin(sb.width / 2.f, 0.f);
        subText.setPosition(WINDOW_W / 2.f, WINDOW_H / 2.f + 50.f);
        rt.draw(subText);
    }

    void drawFieldLabels(sf::RenderTarget& rt) const {
        // Team labels on the sides
        auto drawSideLabel = [&](const std::string& text, float x, float y, sf::Color col) {
            sf::Text t;
            t.setFont(m_font);
            t.setString(text);
            t.setCharacterSize(10);
            t.setFillColor(col);
            t.setStyle(sf::Text::Bold);
            sf::FloatRect tb = t.getLocalBounds();
            t.setOrigin(tb.width / 2.f, tb.height / 2.f);
            t.setPosition(x, y);
            rt.draw(t);
        };
        drawSideLabel("BLUE", FIELD_X - 40.f, FIELD_Y + FIELD_H / 2.f, Colors::NeonCyan);
        drawSideLabel("ORANGE", FIELD_RIGHT + 45.f, FIELD_Y + FIELD_H / 2.f, Colors::NeonOrange);
    }
};

// Minimap (top-right corner)
class Minimap {
public:
    void draw(sf::RenderTarget& rt, sf::Vector2f carPos1, sf::Vector2f carPos2,
              sf::Vector2f ballPos) const {
        const float MX = WINDOW_W - 110.f, MY = 10.f, MW = 100.f, MH = 60.f;
        drawPanel(rt, MX, MY, MW, MH, {10,14,35,210}, Colors::UIBorder, 1.5f);

        auto toMM = [&](sf::Vector2f p) -> sf::Vector2f {
            return {
                MX + (p.x - FIELD_X) / FIELD_W * MW,
                MY + (p.y - FIELD_Y) / FIELD_H * MH
            };
        };

        // Center line
        sf::RectangleShape cl({1.f, MH});
        cl.setPosition(MX + MW/2.f, MY);
        cl.setFillColor({40,55,100,160});
        rt.draw(cl);

        auto drawDot = [&](sf::Vector2f p, sf::Color col, float r = 4.f) {
            sf::CircleShape c(r);
            c.setOrigin(r, r);
            c.setPosition(toMM(p));
            c.setFillColor(col);
            rt.draw(c);
        };

        drawDot(carPos1, Colors::NeonCyan,   3.5f);
        drawDot(carPos2, Colors::NeonOrange, 3.5f);
        drawDot(ballPos, Colors::White,      2.5f);
    }
};
