#pragma once
#include <SFML/Graphics.hpp>
#include "Constants.hpp"
#include <vector>

struct BoostPad {
    sf::Vector2f pos;
    float radius;
    bool  active  = true;
    float respawn = 0.f;
    bool  isBig;

    BoostPad(sf::Vector2f p, bool big = false)
        : pos(p), radius(big ? 20.f : 12.f), isBig(big) {}

    void update(float dt) {
        if (!active) {
            respawn -= dt;
            if (respawn <= 0.f) active = true;
        }
    }

    bool tryCollect(sf::Vector2f carPos, float& boost) {
        if (!active) return false;
        float dx = carPos.x - pos.x, dy = carPos.y - pos.y;
        if (dx*dx + dy*dy < (radius + 20.f)*(radius + 20.f)) {
            float fill = isBig ? BOOST_MAX : BOOST_PAD_FILL;
            boost = std::min(BOOST_MAX, boost + fill);
            active  = false;
            respawn = isBig ? 10.f : 4.f;
            return true;
        }
        return false;
    }

    void draw(sf::RenderTarget& rt, float time) const {
        if (!active) {
            // Faded respawn indicator
            sf::CircleShape c(radius);
            c.setOrigin(radius, radius);
            c.setPosition(pos);
            c.setFillColor({30, 40, 60, 60});
            c.setOutlineColor({60, 70, 100, 80});
            c.setOutlineThickness(1.f);
            rt.draw(c);
            return;
        }

        float pulse = 0.5f + 0.5f * std::sin(time * 4.f);

        // Outer glow
        float gr = radius + 10.f + pulse * 6.f;
        sf::CircleShape glow(gr);
        glow.setOrigin(gr, gr);
        glow.setPosition(pos);
        glow.setFillColor({255, 200, 0, static_cast<sf::Uint8>(30 + pulse * 30)});
        rt.draw(glow);

        // Pad body
        sf::CircleShape pad(radius);
        pad.setOrigin(radius, radius);
        pad.setPosition(pos);
        pad.setFillColor({255, static_cast<sf::Uint8>(180 + pulse*40), 0, 220});
        pad.setOutlineColor({255, 240, 100, 255});
        pad.setOutlineThickness(isBig ? 3.f : 2.f);
        rt.draw(pad);

        // Inner star / diamond for big pads
        if (isBig) {
            sf::RectangleShape star({radius * 1.2f, radius * 1.2f});
            star.setOrigin(radius * 0.6f, radius * 0.6f);
            star.setPosition(pos);
            star.setRotation(45.f + time * 30.f);
            star.setFillColor({255, 255, 180, 150});
            rt.draw(star);
        }
    }
};

// Creates the standard boost pad layout
inline std::vector<BoostPad> createBoostPads() {
    float cx = FIELD_X + FIELD_W / 2.f;
    float cy = FIELD_Y + FIELD_H / 2.f;
    float fw = FIELD_W, fh = FIELD_H;
    float x0 = FIELD_X, y0 = FIELD_Y;

    return {
        // Big pads (corners and center sides)
        BoostPad({x0 + fw*0.1f, y0 + fh*0.15f}, true),
        BoostPad({x0 + fw*0.9f, y0 + fh*0.15f}, true),
        BoostPad({x0 + fw*0.1f, y0 + fh*0.85f}, true),
        BoostPad({x0 + fw*0.9f, y0 + fh*0.85f}, true),
        BoostPad({x0 + fw*0.5f, y0 + fh*0.1f},  true),
        BoostPad({x0 + fw*0.5f, y0 + fh*0.9f},  true),

        // Small pads
        BoostPad({x0 + fw*0.25f, cy}),
        BoostPad({x0 + fw*0.75f, cy}),
        BoostPad({cx, y0 + fh*0.3f}),
        BoostPad({cx, y0 + fh*0.7f}),
        BoostPad({x0 + fw*0.35f, y0 + fh*0.35f}),
        BoostPad({x0 + fw*0.65f, y0 + fh*0.35f}),
        BoostPad({x0 + fw*0.35f, y0 + fh*0.65f}),
        BoostPad({x0 + fw*0.65f, y0 + fh*0.65f}),
    };
}

// Draw the field (ground, lines, goals, decorations)
inline void drawField(sf::RenderTarget& rt, float time) {
    // Background
    rt.clear(Colors::Background);

    // Field ground
    sf::RectangleShape ground({FIELD_W, FIELD_H});
    ground.setPosition(FIELD_X, FIELD_Y);
    ground.setFillColor(Colors::FieldGround);
    rt.draw(ground);

    // Subtle striped grass effect
    for (int i = 0; i < 8; i++) {
        sf::RectangleShape stripe({FIELD_W / 8.f - 1.f, FIELD_H});
        stripe.setPosition(FIELD_X + i * FIELD_W / 8.f, FIELD_Y);
        stripe.setFillColor({20, 26, 54, static_cast<sf::Uint8>(i % 2 == 0 ? 0 : 20)});
        rt.draw(stripe);
    }

    // Center circle
    sf::CircleShape cc(70.f);
    cc.setOrigin(70.f, 70.f);
    cc.setPosition(FIELD_X + FIELD_W/2.f, FIELD_Y + FIELD_H/2.f);
    cc.setFillColor({0,0,0,0});
    cc.setOutlineColor(Colors::FieldLine);
    cc.setOutlineThickness(2.f);
    rt.draw(cc);

    // Center line
    sf::RectangleShape cline({2.f, FIELD_H});
    cline.setPosition(FIELD_X + FIELD_W/2.f - 1.f, FIELD_Y);
    cline.setFillColor(Colors::FieldLine);
    rt.draw(cline);

    // Center dot
    sf::CircleShape cdot(5.f);
    cdot.setOrigin(5.f, 5.f);
    cdot.setPosition(FIELD_X + FIELD_W/2.f, FIELD_Y + FIELD_H/2.f);
    cdot.setFillColor(Colors::FieldLine);
    rt.draw(cdot);

    // Field border
    sf::RectangleShape border({FIELD_W, FIELD_H});
    border.setPosition(FIELD_X, FIELD_Y);
    border.setFillColor({0,0,0,0});
    border.setOutlineColor(Colors::NeonCyan);
    border.setOutlineThickness(3.f);
    rt.draw(border);

    // Goals
    // Left (blue) goal
    sf::RectangleShape goalL({GOAL_W + 4.f, GOAL_H});
    goalL.setPosition(GOAL_LEFT_X - 4.f, GOAL_Y);
    goalL.setFillColor(Colors::GoalBlue);
    goalL.setOutlineColor(Colors::NeonBlue);
    goalL.setOutlineThickness(3.f);
    rt.draw(goalL);

    // Right (orange) goal
    sf::RectangleShape goalR({GOAL_W + 4.f, GOAL_H});
    goalR.setPosition(GOAL_RIGHT_X, GOAL_Y);
    goalR.setFillColor(Colors::GoalOrange);
    goalR.setOutlineColor(Colors::NeonOrange);
    goalR.setOutlineThickness(3.f);
    rt.draw(goalR);

    // Goal posts (top and bottom)
    for (float gy : {GOAL_Y, GOAL_Y + GOAL_H}) {
        // Left goal post
        sf::RectangleShape post({GOAL_W + 8.f, 6.f});
        post.setPosition(GOAL_LEFT_X - 4.f, gy - 3.f);
        post.setFillColor(Colors::NeonBlue);
        rt.draw(post);
        // Right goal post
        sf::RectangleShape post2({GOAL_W + 8.f, 6.f});
        post2.setPosition(GOAL_RIGHT_X, gy - 3.f);
        post2.setFillColor(Colors::NeonOrange);
        rt.draw(post2);
    }

    // Corner arcs
    float cornerR = 50.f;
    const std::pair<float,float> corners[] = {
        {FIELD_X, FIELD_Y},
        {FIELD_RIGHT, FIELD_Y},
        {FIELD_X, FIELD_BOTTOM},
        {FIELD_RIGHT, FIELD_BOTTOM}
    };
    float startAngles[] = {180.f, 270.f, 90.f, 0.f};
    for (int i = 0; i < 4; i++) {
        sf::CircleShape arc(cornerR);
        arc.setOrigin(cornerR, cornerR);
        arc.setPosition(corners[i].first, corners[i].second);
        arc.setFillColor({0,0,0,0});
        arc.setOutlineColor(Colors::FieldLine);
        arc.setOutlineThickness(2.f);
        rt.draw(arc);
    }
}
