#pragma once
#include <SFML/Graphics.hpp>
#include <vector>
#include <random>
#include "Constants.hpp"

struct Particle {
    sf::Vector2f pos;
    sf::Vector2f vel;
    float life;
    float maxLife;
    sf::Color color;
    float radius;
    float drag;
};

class ParticleSystem {
public:
    std::vector<Particle> particles;
    std::mt19937 rng{42};

    void emit(sf::Vector2f pos, sf::Color col, int count,
              float speedMin, float speedMax, float lifeMin, float lifeMax,
              float radius = 4.f, float angleMin = 0.f, float angleMax = 360.f,
              float drag = 0.95f)
    {
        std::uniform_real_distribution<float> angle(angleMin, angleMax);
        std::uniform_real_distribution<float> speed(speedMin, speedMax);
        std::uniform_real_distribution<float> life(lifeMin, lifeMax);
        std::uniform_real_distribution<float> r(radius * 0.5f, radius * 1.5f);

        for (int i = 0; i < count; i++) {
            float a = angle(rng) * 3.14159265f / 180.f;
            float s = speed(rng);
            particles.push_back({
                pos,
                {std::cos(a) * s, std::sin(a) * s},
                life(rng), life(rng),
                col,
                r(rng),
                drag
            });
        }
    }

    void emitBoost(sf::Vector2f pos, float carAngle, sf::Color col) {
        float backAngle = carAngle + 180.f;
        emit(pos, {col.r, col.g, col.b, 200}, 3,
             80.f, 160.f, 0.15f, 0.35f, 3.f,
             backAngle - 20.f, backAngle + 20.f, 0.90f);
    }

    void emitGoal(sf::Vector2f pos) {
        // Gold/yellow explosion
        emit(pos, {255, 220, 50, 255},  30, 80.f, 300.f, 0.5f, 1.5f, 6.f);
        emit(pos, {255, 140, 0,  220},  20, 60.f, 200.f, 0.4f, 1.2f, 5.f);
        emit(pos, {255, 255, 255, 200}, 15, 40.f, 150.f, 0.3f, 0.8f, 4.f);
    }

    void emitBallHit(sf::Vector2f pos, sf::Vector2f dir) {
        float baseAngle = std::atan2(dir.y, dir.x) * 180.f / 3.14159265f;
        emit(pos, {200, 220, 255, 200}, 8, 40.f, 120.f, 0.2f, 0.5f, 3.f,
             baseAngle - 60.f, baseAngle + 60.f, 0.92f);
    }

    void emitBoostCollect(sf::Vector2f pos) {
        emit(pos, {255, 220, 50, 240}, 12, 50.f, 150.f, 0.3f, 0.7f, 4.f);
    }

    void update(float dt) {
        for (auto& p : particles) {
            p.life -= dt;
            p.pos  += p.vel * dt;
            p.vel  *= p.drag;
        }
        particles.erase(std::remove_if(particles.begin(), particles.end(),
            [](const Particle& p) { return p.life <= 0.f; }), particles.end());
    }

    void draw(sf::RenderTarget& rt) const {
        for (const auto& p : particles) {
            float t = p.life / p.maxLife;
            sf::Uint8 alpha = static_cast<sf::Uint8>(p.color.a * t);
            float radius    = p.radius * (0.4f + t * 0.6f);

            sf::CircleShape c(radius);
            c.setOrigin(radius, radius);
            c.setPosition(p.pos);
            c.setFillColor({p.color.r, p.color.g, p.color.b, alpha});
            rt.draw(c);
        }
    }
};
