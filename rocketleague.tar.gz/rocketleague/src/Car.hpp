#pragma once
#include <SFML/Graphics.hpp>
#include "Constants.hpp"
#include "Math.hpp"
#include <string>
#include <cmath>
#include <array>

struct Car {
    sf::Vector2f pos;
    sf::Vector2f vel;
    float angle   = 0.f;   // degrees, 0 = right
    float boost   = 50.f;
    float z       = 0.f;   // height (for jump)
    float vz      = 0.f;
    bool  onGround = true;
    bool  boosting = false;
    float jumpCooldown = 0.f;

    sf::Color   bodyColor;
    sf::Color   accentColor;
    std::string name;

    // Controls (set each frame by input handler or AI)
    float throttle = 0.f;  // -1 to 1
    float steer    = 0.f;  // -1 to 1
    bool  wantBoost= false;
    bool  wantJump = false;

    // For visual effects
    float boostParticleTimer = 0.f;
    bool  scored = false;

    Car() = default;
    Car(sf::Vector2f startPos, float startAngle, sf::Color body, sf::Color accent, const std::string& playerName)
        : pos(startPos), angle(startAngle), bodyColor(body), accentColor(accent), name(playerName)
    {}

    void reset(sf::Vector2f startPos, float startAngle) {
        pos   = startPos;
        vel   = {0.f, 0.f};
        angle = startAngle;
        boost = 34.f;
        z     = 0.f;
        vz    = 0.f;
        onGround = true;
        jumpCooldown = 0.f;
        throttle = 0.f;
        steer    = 0.f;
        wantBoost = false;
        wantJump  = false;
    }

    void update(float dt) {
        boosting = wantBoost && boost > 0.f && onGround;

        // --- Jump ---
        jumpCooldown -= dt;
        if (wantJump && onGround && jumpCooldown <= 0.f) {
            vz = JUMP_VY;
            z  = 1.f;
            onGround = false;
            jumpCooldown = 0.5f;
        }

        // --- Z physics ---
        if (!onGround) {
            vz += GRAVITY * dt;
            z  += vz * dt;
            if (z >= 0.f) {
                z = 0.f;
                vz = 0.f;
                onGround = true;
            }
        }

        // --- Steering (only when on ground) ---
        float maxSpeed = boosting ? CAR_BOOST_SPEED : CAR_SPEED;
        float speedRatio = Math::length(vel) / maxSpeed;

        if (onGround && std::abs(throttle) > 0.01f) {
            // Steering angle scales with speed (more turn when moving)
            float turnAmount = steer * CAR_TURN_SPEED * dt * Math::clamp(speedRatio + 0.3f, 0.f, 1.f);
            angle += turnAmount;
        }

        // --- Thrust ---
        sf::Vector2f dir = Math::fromAngleDeg(angle);
        float accel = throttle > 0.f ? CAR_ACCEL : CAR_BRAKE_FORCE;
        if (boosting) accel *= 1.5f;

        vel += dir * throttle * accel * dt;

        // Speed cap
        float spd = Math::length(vel);
        if (spd > maxSpeed) {
            vel = Math::normalize(vel) * maxSpeed;
        }

        // Friction
        vel *= std::pow(onGround ? CAR_FRICTION : 0.98f, dt * 60.f);

        // Move
        pos += vel * dt;

        // Boost drain
        if (boosting) {
            boost -= BOOST_DRAIN * dt;
            if (boost < 0.f) boost = 0.f;
        }

        // Clamp to field
        float hw = CAR_W / 2.f;
        float hh = CAR_H / 2.f;
        pos.x = Math::clamp(pos.x, FIELD_X + hw, FIELD_RIGHT - hw);
        pos.y = Math::clamp(pos.y, FIELD_Y + hh, FIELD_BOTTOM - hh);

        // Handle wall collision velocity zero-out
        if (pos.x <= FIELD_X + hw + 1.f || pos.x >= FIELD_RIGHT - hw - 1.f)  vel.x = 0.f;
        if (pos.y <= FIELD_Y + hh + 1.f || pos.y >= FIELD_BOTTOM - hh - 1.f) vel.y = 0.f;

        boostParticleTimer -= dt;
    }

    // Returns a rotated rectangle (4 corners) for collision
    std::array<sf::Vector2f, 4> corners() const {
        float rad = angle * 3.14159265f / 180.f;
        float cs = std::cos(rad), sn = std::sin(rad);
        float hw = CAR_W / 2.f, hh = CAR_H / 2.f;
        // All 4 corners
        return {
            pos + sf::Vector2f{ cs*hw - sn*hh,  sn*hw + cs*hh},
            pos + sf::Vector2f{-cs*hw - sn*hh, -sn*hw + cs*hh},
            pos + sf::Vector2f{-cs*hw + sn*hh, -sn*hw - cs*hh},
            pos + sf::Vector2f{ cs*hw + sn*hh,  sn*hw - cs*hh}
        };
    }

    void draw(sf::RenderTarget& rt, const sf::Font& font) const {
        float drawY = pos.y + z;  // z is negative when in air

        // Boost flame trail
        if (boosting) {
            float rad = (angle + 180.f) * 3.14159265f / 180.f;
            sf::Vector2f flameDir = {std::cos(rad), std::sin(rad)};
            for (int i = 0; i < 3; i++) {
                float t = (i + 1) * 0.3f;
                sf::CircleShape flame(8.f - i * 2.f);
                flame.setOrigin(8.f - i * 2.f, 8.f - i * 2.f);
                flame.setPosition(pos.x + flameDir.x * (CAR_W * 0.4f + i * 8.f),
                                  drawY + flameDir.y * (CAR_W * 0.4f + i * 8.f));
                sf::Uint8 alpha = static_cast<sf::Uint8>(200 - i * 60);
                flame.setFillColor({255, static_cast<sf::Uint8>(140 - i*40), 0, alpha});
                rt.draw(flame);
            }
        }

        // Car shadow
        sf::RectangleShape shadow({CAR_W, CAR_H});
        shadow.setOrigin(CAR_W / 2.f, CAR_H / 2.f);
        shadow.setPosition(pos);
        shadow.setRotation(angle);
        shadow.setFillColor({0, 0, 0, static_cast<sf::Uint8>(z < 0.f ? 60 : 0)});
        if (z < 0.f) rt.draw(shadow);

        // Car body
        sf::RectangleShape body({CAR_W, CAR_H});
        body.setOrigin(CAR_W / 2.f, CAR_H / 2.f);
        body.setPosition(pos.x, drawY);
        body.setRotation(angle);
        body.setFillColor(bodyColor);
        body.setOutlineThickness(2.f);
        body.setOutlineColor(accentColor);
        rt.draw(body);

        // Car roof / windshield detail
        sf::RectangleShape roof({CAR_W * 0.55f, CAR_H * 0.55f});
        roof.setOrigin(CAR_W * 0.55f / 2.f, CAR_H * 0.55f / 2.f);
        roof.setPosition(pos.x, drawY);
        roof.setRotation(angle);
        roof.setFillColor({accentColor.r, accentColor.g, accentColor.b, 80});
        rt.draw(roof);

        // Headlights
        float rad = angle * 3.14159265f / 180.f;
        sf::Vector2f fwd = {std::cos(rad), std::sin(rad)};
        sf::Vector2f side = {-std::sin(rad), std::cos(rad)};
        for (int s : {-1, 1}) {
            sf::CircleShape light(3.5f);
            light.setOrigin(3.5f, 3.5f);
            light.setPosition(pos.x + fwd.x * (CAR_W*0.48f) + side.x * s * (CAR_H*0.28f),
                              drawY + fwd.y * (CAR_W*0.48f) + side.y * s * (CAR_H*0.28f));
            light.setFillColor(accentColor);
            rt.draw(light);
        }

        // Boost glow when boosting
        if (boosting) {
            sf::CircleShape glow(CAR_W * 0.8f);
            glow.setOrigin(CAR_W * 0.8f, CAR_W * 0.8f);
            glow.setPosition(pos.x, drawY);
            glow.setFillColor({accentColor.r, accentColor.g, accentColor.b, 30});
            rt.draw(glow);
        }

        // Name tag
        sf::Text tag;
        tag.setFont(font);
        tag.setString(name);
        tag.setCharacterSize(11);
        tag.setFillColor(Colors::White);
        tag.setOutlineColor({0,0,0,180});
        tag.setOutlineThickness(1.5f);
        sf::FloatRect tb = tag.getLocalBounds();
        tag.setOrigin(tb.width / 2.f, tb.height);
        tag.setPosition(pos.x, drawY - CAR_H / 2.f - 10.f);
        rt.draw(tag);

        // Boost bar under name
        float boostPct = boost / BOOST_MAX;
        float barW = 36.f;
        sf::RectangleShape barBg({barW, 4.f});
        barBg.setOrigin(barW / 2.f, 0.f);
        barBg.setPosition(pos.x, drawY - CAR_H / 2.f - 7.f);
        barBg.setFillColor({30, 30, 50, 180});
        rt.draw(barBg);
        sf::RectangleShape barFill({barW * boostPct, 4.f});
        barFill.setOrigin(0.f, 0.f);
        barFill.setPosition(pos.x - barW / 2.f, drawY - CAR_H / 2.f - 7.f);
        sf::Color bCol = boostPct > 0.5f ? Colors::BoostYellow : sf::Color{255, 80, 0, 255};
        barFill.setFillColor(bCol);
        rt.draw(barFill);
    }
};
