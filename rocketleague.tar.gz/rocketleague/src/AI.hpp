#pragma once
#include "Car.hpp"
#include "Ball.hpp"
#include "Math.hpp"
#include <cmath>

// Basic AI that chases the ball and tries to shoot toward the opponent's goal
class AIController {
public:
    float reactionTimer = 0.f;
    float targetAngle   = 0.f;
    bool  attacking     = true;  // true = try to score, false = defend

    void update(Car& car, const Ball& ball, float dt) {
        reactionTimer -= dt;
        if (reactionTimer <= 0.f) {
            reactionTimer = 0.1f;  // update AI decision 10x/second
            decide(car, ball);
        }
        applySteering(car, dt);
    }

private:
    sf::Vector2f m_targetPos;

    void decide(Car& car, const Ball& ball) {
        // Decide target position
        // AI plays on the right (orange) side, scores in left goal
        sf::Vector2f leftGoalCenter = {FIELD_X - 20.f, FIELD_Y + FIELD_H / 2.f};
        sf::Vector2f myGoalCenter   = {FIELD_RIGHT + 20.f, FIELD_Y + FIELD_H / 2.f};

        // Ball position
        sf::Vector2f bpos = ball.pos;

        // If ball is on our half, be defensive; else attack
        attacking = bpos.x < FIELD_X + FIELD_W * 0.65f;

        if (attacking) {
            // Position behind ball aiming at goal
            sf::Vector2f toBallFromGoal = Math::normalize(bpos - leftGoalCenter);
            // Stand 50px behind the ball relative to goal
            m_targetPos = bpos + toBallFromGoal * 55.f;
        } else {
            // Go defend near our goal, between ball and goal
            sf::Vector2f toGoalFromBall = Math::normalize(myGoalCenter - bpos);
            m_targetPos = myGoalCenter + toGoalFromBall * (-100.f);
            // Clamp inside field
            m_targetPos.x = Math::clamp(m_targetPos.x, FIELD_X + 20.f, FIELD_RIGHT - 20.f);
            m_targetPos.y = Math::clamp(m_targetPos.y, FIELD_Y + 20.f, FIELD_BOTTOM - 20.f);
        }

        // Compute desired heading
        sf::Vector2f toTarget = m_targetPos - car.pos;
        targetAngle = std::atan2(toTarget.y, toTarget.x) * 180.f / 3.14159265f;
    }

    void applySteering(Car& car, float dt) {
        // Compute angle difference
        float diff = targetAngle - car.angle;
        // Normalize to [-180, 180]
        while (diff >  180.f) diff -= 360.f;
        while (diff < -180.f) diff += 360.f;

        float dist = Math::length(m_targetPos - car.pos);

        // Steer
        car.steer    = Math::clamp(diff / 30.f, -1.f, 1.f);
        car.throttle = dist > 20.f ? 1.f : 0.f;

        // Use boost when far from target and attacking and boost > 30
        car.wantBoost = (dist > 200.f && attacking && car.boost > 30.f);

        // Don't jump (AI keeps it simple)
        car.wantJump  = false;
    }
};
