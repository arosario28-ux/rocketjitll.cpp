#pragma once
#include <SFML/Graphics.hpp>

// Window
constexpr int WINDOW_W = 1280;
constexpr int WINDOW_H = 720;
constexpr float FPS = 60.f;
constexpr float DT = 1.f / FPS;

// Field
constexpr float FIELD_X      = 80.f;
constexpr float FIELD_Y      = 100.f;
constexpr float FIELD_W      = 1120.f;
constexpr float FIELD_H      = 540.f;
constexpr float FIELD_RIGHT  = FIELD_X + FIELD_W;
constexpr float FIELD_BOTTOM = FIELD_Y + FIELD_H;

// Goals
constexpr float GOAL_W       = 8.f;
constexpr float GOAL_H       = 160.f;
constexpr float GOAL_Y       = FIELD_Y + (FIELD_H - GOAL_H) / 2.f;
constexpr float GOAL_LEFT_X  = FIELD_X - GOAL_W;
constexpr float GOAL_RIGHT_X = FIELD_RIGHT;

// Ball
constexpr float BALL_RADIUS   = 18.f;
constexpr float BALL_FRICTION = 0.988f;
constexpr float BALL_RESTITUTION = 0.75f;

// Car
constexpr float CAR_W         = 44.f;
constexpr float CAR_H         = 26.f;
constexpr float CAR_SPEED     = 280.f;
constexpr float CAR_BOOST_SPEED = 460.f;
constexpr float CAR_TURN_SPEED  = 200.f;  // degrees/s
constexpr float CAR_FRICTION    = 0.92f;
constexpr float CAR_ACCEL       = 600.f;
constexpr float CAR_BRAKE_FORCE = 700.f;
constexpr float JUMP_VY        = -380.f;
constexpr float GRAVITY        = 700.f;
constexpr float BOOST_MAX      = 100.f;
constexpr float BOOST_DRAIN    = 33.f;   // per second
constexpr float BOOST_REGEN    = 0.f;
constexpr float BOOST_PAD_FILL = 25.f;

// Game
constexpr float MATCH_TIME    = 180.f;   // 3 minutes

// Colors (Rocket League palette)
namespace Colors {
    const sf::Color Background  {10,  12,  25,  255};
    const sf::Color FieldGround {18,  22,  48,  255};
    const sf::Color FieldLine   {40,  55,  100, 180};
    const sf::Color WallColor   {25,  35,  70,  255};
    const sf::Color NeonCyan    {0,   220, 255, 255};
    const sf::Color NeonOrange  {255, 140, 0,   255};
    const sf::Color NeonBlue    {30,  100, 255, 255};
    const sf::Color GoalBlue    {0,   80,  200, 120};
    const sf::Color GoalOrange  {200, 80,  0,   120};
    const sf::Color UIPanel     {15,  18,  40,  220};
    const sf::Color UIBorder    {0,   180, 220, 200};
    const sf::Color White       {255, 255, 255, 255};
    const sf::Color Gray        {120, 130, 150, 255};
    const sf::Color BoostYellow {255, 220, 0,   255};
    const sf::Color BallColor   {230, 230, 240, 255};
    const sf::Color BallOutline {80,  90,  110, 255};
    const sf::Color Car1Color   {0,   200, 255, 255};
    const sf::Color Car2Color   {255, 120, 0,   255};
    const sf::Color BoostPad    {255, 220, 50,  200};
    const sf::Color BoostPadGlow{255, 180, 0,   80};
    const sf::Color GoalFlash   {255, 255, 100, 200};
}
