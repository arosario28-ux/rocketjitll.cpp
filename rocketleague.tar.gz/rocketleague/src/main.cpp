#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <iostream>
#include <string>
#include <cmath>
#include <algorithm>

#include "Constants.hpp"
#include "Math.hpp"
#include "Ball.hpp"
#include "Car.hpp"
#include "Field.hpp"
#include "HUD.hpp"
#include "Particles.hpp"
#include "AI.hpp"
#include "Collision.hpp"

// ─── Game States ─────────────────────────────────────────────────────────────
enum class GameState { Menu, Playing, GoalCelebration, GameOver };

// ─── Main Game Class ──────────────────────────────────────────────────────────
class RocketLeagueGame {
public:
    RocketLeagueGame()
        : m_window(sf::VideoMode(WINDOW_W, WINDOW_H), "Rocket League (C++ / SFML)",
                   sf::Style::Titlebar | sf::Style::Close)
        , m_hud(m_font)
    {
        m_window.setFramerateLimit(static_cast<unsigned>(FPS));

        if (!m_font.loadFromFile("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf") &&
            !m_font.loadFromFile("/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf") &&
            !m_font.loadFromFile("/usr/share/fonts/truetype/freefont/FreeSansBold.ttf")) {
            std::cerr << "Warning: Could not load font. Text may not display.\n";
        }

        resetMatch();
    }

    void run() {
        sf::Clock clock;
        while (m_window.isOpen()) {
            float dt = clock.restart().asSeconds();
            dt = std::min(dt, 0.05f);  // cap dt to avoid physics explosions
            m_time += dt;

            handleEvents();

            if (m_state == GameState::Playing) {
                update(dt);
            } else if (m_state == GameState::GoalCelebration) {
                updateGoalCelebration(dt);
            } else if (m_state == GameState::Menu) {
                // nothing dynamic
            }

            render();
        }
    }

private:
    sf::RenderWindow   m_window;
    sf::Font           m_font;
    HUD                m_hud;
    Minimap            m_minimap;
    ParticleSystem     m_particles;
    AIController       m_ai;

    Ball m_ball;
    Car  m_car1, m_car2;
    std::vector<BoostPad> m_boostPads;

    int   m_scoreLeft  = 0;
    int   m_scoreRight = 0;
    float m_timeLeft   = MATCH_TIME;
    float m_time       = 0.f;

    GameState m_state = GameState::Menu;
    bool      m_camBall    = true;
    bool      m_overtime   = false;

    float       m_goalFlash   = 0.f;
    std::string m_goalMsg;
    float       m_celebTimer  = 0.f;
    int         m_lastScorer  = 0;   // 1 = blue, 2 = orange

    void resetMatch() {
        m_scoreLeft  = 0;
        m_scoreRight = 0;
        m_timeLeft   = MATCH_TIME;
        m_overtime   = false;
        m_boostPads  = createBoostPads();
        resetRound(0);
    }

    void resetRound(int lastScorer) {
        m_ball.reset();

        float cx = FIELD_X + FIELD_W / 2.f;
        float cy = FIELD_Y + FIELD_H / 2.f;

        // Car 1 (Blue, left side, WASD)
        m_car1 = Car({cx - 150.f, cy}, 0.f, Colors::Car1Color, Colors::NeonCyan, "PLAYER");
        m_car1.boost = 34.f;

        // Car 2 (Orange, right side, AI)
        m_car2 = Car({cx + 150.f, cy}, 180.f, Colors::Car2Color, Colors::NeonOrange, "BOT-R852");
        m_car2.boost = 34.f;

        m_goalFlash  = 0.f;
    }

    // ─── Input ─────────────────────────────────────────────────────────────────
    void handleEvents() {
        sf::Event ev;
        while (m_window.pollEvent(ev)) {
            if (ev.type == sf::Event::Closed)
                m_window.close();

            if (ev.type == sf::Event::KeyPressed) {
                if (ev.key.code == sf::Keyboard::Escape)
                    m_window.close();

                if (m_state == GameState::Menu && ev.key.code == sf::Keyboard::Enter) {
                    m_state = GameState::Playing;
                    resetMatch();
                }
                if (m_state == GameState::GameOver && ev.key.code == sf::Keyboard::R) {
                    m_state = GameState::Menu;
                }
                if (m_state == GameState::Playing) {
                    if (ev.key.code == sf::Keyboard::C)
                        m_camBall = !m_camBall;
                }
            }
        }
    }

    void readPlayerInput() {
        // Player 1: WASD + Shift (boost) + Space (jump)
        m_car1.throttle = 0.f;
        m_car1.steer    = 0.f;
        m_car1.wantBoost= false;
        m_car1.wantJump = false;

        if (sf::Keyboard::isKeyPressed(sf::Keyboard::W))     m_car1.throttle =  1.f;
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::S))     m_car1.throttle = -0.7f;
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::A))     m_car1.steer    = -1.f;
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::D))     m_car1.steer    =  1.f;
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::LShift)||
            sf::Keyboard::isKeyPressed(sf::Keyboard::RShift)) m_car1.wantBoost = true;
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space)) m_car1.wantJump  = true;

        // Arrow keys alternative
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up))    m_car1.throttle =  1.f;
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down))  m_car1.throttle = -0.7f;
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))  m_car1.steer    = -1.f;
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) m_car1.steer    =  1.f;
    }

    // ─── Update ────────────────────────────────────────────────────────────────
    void update(float dt) {
        readPlayerInput();
        m_ai.update(m_car2, m_ball, dt);

        // Update cars
        m_car1.update(dt);
        m_car2.update(dt);

        // Update ball
        m_ball.update(dt);

        // Boost particles
        if (m_car1.boosting) m_particles.emitBoost(m_car1.pos, m_car1.angle, Colors::NeonCyan);
        if (m_car2.boosting) m_particles.emitBoost(m_car2.pos, m_car2.angle, Colors::NeonOrange);

        // Collisions: Ball vs Cars
        auto impulse1 = resolveBallCar(m_ball.pos, m_ball.vel, BALL_RADIUS,
                                        m_car1.pos, m_car1.vel, CAR_W, CAR_H, m_car1.angle);
        if (Math::length(impulse1) > 10.f) {
            m_particles.emitBallHit(m_ball.pos, Math::normalize(impulse1));
        }

        auto impulse2 = resolveBallCar(m_ball.pos, m_ball.vel, BALL_RADIUS,
                                        m_car2.pos, m_car2.vel, CAR_W, CAR_H, m_car2.angle);
        if (Math::length(impulse2) > 10.f) {
            m_particles.emitBallHit(m_ball.pos, Math::normalize(impulse2));
        }

        // Car vs Car (simple pushback)
        auto carCol = circleVsCircle(m_car1.pos, CAR_W * 0.45f, m_car2.pos, CAR_W * 0.45f);
        if (carCol.hit) {
            m_car1.pos += carCol.normal * carCol.depth * 0.5f;
            m_car2.pos -= carCol.normal * carCol.depth * 0.5f;
            sf::Vector2f rv = m_car1.vel - m_car2.vel;
            float vn = Math::dot(rv, carCol.normal);
            if (vn < 0.f) {
                sf::Vector2f impulse = carCol.normal * vn * 0.6f;
                m_car1.vel -= impulse;
                m_car2.vel += impulse;
            }
        }

        // Boost pads
        for (auto& pad : m_boostPads) {
            pad.update(dt);
            if (pad.tryCollect(m_car1.pos, m_car1.boost))
                m_particles.emitBoostCollect(pad.pos);
            if (pad.tryCollect(m_car2.pos, m_car2.boost))
                m_particles.emitBoostCollect(pad.pos);
        }

        // Particles
        m_particles.update(dt);

        // Goal detection
        if (m_ball.inLeftGoal()) {
            // Orange scores
            m_scoreRight++;
            m_lastScorer = 2;
            m_goalMsg    = "BOT-R852 SCORES!";
            triggerGoal();
        } else if (m_ball.inRightGoal()) {
            // Blue scores
            m_scoreLeft++;
            m_lastScorer = 1;
            m_goalMsg    = "PLAYER SCORES!";
            triggerGoal();
        }

        // Timer
        if (!m_overtime) {
            m_timeLeft -= dt;
            if (m_timeLeft <= 0.f) {
                m_timeLeft = 0.f;
                if (m_scoreLeft != m_scoreRight) {
                    // Game over
                    m_state = GameState::GameOver;
                } else {
                    m_overtime = true;
                }
            }
        }
    }

    void triggerGoal() {
        m_particles.emitGoal(m_ball.pos);
        m_goalFlash  = 2.5f;  // seconds
        m_celebTimer = 2.5f;
        m_state      = GameState::GoalCelebration;
    }

    void updateGoalCelebration(float dt) {
        m_goalFlash  -= dt;
        m_celebTimer -= dt;
        m_particles.update(dt);
        if (m_celebTimer <= 0.f) {
            // Check if game should end
            if (!m_overtime && m_timeLeft <= 0.f && m_scoreLeft != m_scoreRight) {
                m_state = GameState::GameOver;
            } else {
                resetRound(m_lastScorer);
                m_state = GameState::Playing;
            }
        }
    }

    // ─── Render ────────────────────────────────────────────────────────────────
    void render() {
        if (m_state == GameState::Menu) {
            renderMenu();
            return;
        }
        if (m_state == GameState::GameOver) {
            renderGameOver();
            return;
        }

        // Field
        drawField(m_window, m_time);

        // Boost pads
        for (const auto& pad : m_boostPads)
            pad.draw(m_window, m_time);

        // Particles (behind cars)
        m_particles.draw(m_window);

        // Cars
        m_car1.draw(m_window, m_font);
        m_car2.draw(m_window, m_font);

        // Ball (on top)
        m_ball.draw(m_window);

        // HUD
        m_hud.draw(m_window, m_scoreLeft, m_scoreRight, m_timeLeft,
                   m_car1.boost, m_car2.boost, m_camBall,
                   m_goalMsg, m_goalFlash, m_overtime, m_time);

        // Minimap
        m_minimap.draw(m_window, m_car1.pos, m_car2.pos, m_ball.pos);

        // Controls hint (bottom center, subtle)
        drawControlsHint();

        m_window.display();
    }

    void renderMenu() {
        m_window.clear(Colors::Background);

        // Decorative neon lines
        for (int i = 0; i < 5; i++) {
            sf::RectangleShape line({(float)WINDOW_W, 1.f});
            line.setPosition(0.f, 100.f + i * 130.f);
            line.setFillColor({0, 180, 220, static_cast<sf::Uint8>(20 + i*10)});
            m_window.draw(line);
        }

        auto drawCenteredText = [&](const std::string& str, float y, unsigned sz,
                                     sf::Color col, bool bold = false) {
            sf::Text t;
            t.setFont(m_font);
            t.setString(str);
            t.setCharacterSize(sz);
            t.setFillColor(col);
            if (bold) t.setStyle(sf::Text::Bold);
            sf::FloatRect b = t.getLocalBounds();
            t.setOrigin(b.width/2.f, b.height/2.f);
            t.setPosition(WINDOW_W/2.f, y);
            m_window.draw(t);
        };

        // Title glow
        sf::Text glowTitle;
        glowTitle.setFont(m_font);
        glowTitle.setString("ROCKET LEAGUE");
        glowTitle.setCharacterSize(72);
        glowTitle.setStyle(sf::Text::Bold);
        glowTitle.setFillColor({0, 180, 255, 40});
        sf::FloatRect gb = glowTitle.getLocalBounds();
        glowTitle.setOrigin(gb.width/2.f, gb.height/2.f);
        glowTitle.setPosition(WINDOW_W/2.f + 3.f, WINDOW_H*0.28f + 3.f);
        m_window.draw(glowTitle);

        drawCenteredText("ROCKET LEAGUE",  WINDOW_H*0.28f, 72, Colors::NeonCyan, true);
        drawCenteredText("C++ / SFML Edition", WINDOW_H*0.38f, 22, Colors::NeonOrange);

        // Blue separator bar
        sf::RectangleShape sep({500.f, 2.f});
        sep.setOrigin(250.f, 1.f);
        sep.setPosition(WINDOW_W/2.f, WINDOW_H*0.44f);
        sep.setFillColor(Colors::UIBorder);
        m_window.draw(sep);

        // Controls
        drawCenteredText("CONTROLS", WINDOW_H*0.50f, 16, Colors::Gray);
        drawCenteredText("W/A/S/D or Arrow Keys   -   Drive", WINDOW_H*0.57f, 14, Colors::White);
        drawCenteredText("Shift   -   Boost          Space   -   Jump", WINDOW_H*0.63f, 14, Colors::White);
        drawCenteredText("C   -   Toggle Camera      ESC   -   Quit", WINDOW_H*0.69f, 14, Colors::White);

        // Blink ENTER
        float pulse = 0.5f + 0.5f * std::sin(m_time * 3.f);
        sf::Uint8 alpha = static_cast<sf::Uint8>(180 + pulse * 75);
        drawCenteredText("PRESS ENTER TO PLAY",
                         WINDOW_H*0.82f, 26,
                         {Colors::NeonCyan.r, Colors::NeonCyan.g, Colors::NeonCyan.b, alpha}, true);

        m_window.display();
        m_time += 0.016f;
    }

    void renderGameOver() {
        m_window.clear(Colors::Background);

        auto drawCenteredText = [&](const std::string& str, float y, unsigned sz,
                                     sf::Color col, bool bold = false) {
            sf::Text t;
            t.setFont(m_font);
            t.setString(str);
            t.setCharacterSize(sz);
            t.setFillColor(col);
            if (bold) t.setStyle(sf::Text::Bold);
            sf::FloatRect b = t.getLocalBounds();
            t.setOrigin(b.width/2.f, b.height/2.f);
            t.setPosition(WINDOW_W/2.f, y);
            m_window.draw(t);
        };

        bool playerWon = m_scoreLeft > m_scoreRight;
        sf::Color winCol = playerWon ? Colors::NeonCyan : Colors::NeonOrange;
        std::string winStr = playerWon ? "PLAYER WINS!" : "BOT WINS!";

        drawCenteredText("MATCH OVER", WINDOW_H*0.25f, 50, Colors::White, true);
        drawCenteredText(winStr,       WINDOW_H*0.40f, 60, winCol, true);

        std::string scoreStr = std::to_string(m_scoreLeft) + "  :  " + std::to_string(m_scoreRight);
        drawCenteredText(scoreStr, WINDOW_H*0.55f, 48, Colors::White, true);

        drawCenteredText("PRESS R TO RETURN TO MENU", WINDOW_H*0.72f, 20, Colors::Gray);

        m_window.display();
    }

    void drawControlsHint() {
        sf::Text hint;
        hint.setFont(m_font);
        hint.setString("WASD/Arrows: Drive  |  Shift: Boost  |  Space: Jump  |  C: Camera");
        hint.setCharacterSize(10);
        hint.setFillColor({100, 110, 140, 160});
        sf::FloatRect hb = hint.getLocalBounds();
        hint.setOrigin(hb.width/2.f, 0.f);
        hint.setPosition(WINDOW_W/2.f, WINDOW_H - 18.f);
        m_window.draw(hint);
    }
};

// ─── Entry Point ─────────────────────────────────────────────────────────────
int main() {
    try {
        RocketLeagueGame game;
        game.run();
    } catch (const std::exception& e) {
        std::cerr << "Fatal error: " << e.what() << "\n";
        return 1;
    }
    return 0;
}
