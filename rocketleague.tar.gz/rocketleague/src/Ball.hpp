#pragma once
#include <SFML/Graphics.hpp>
#include "Constants.hpp"
#include "Math.hpp"

class Ball {
public:
    sf::Vector2f pos;
    sf::Vector2f vel;
    float z  = 0.f;   // height above ground (for jump shadow)
    float vz = 0.f;   // vertical velocity (z-axis)

    Ball() {
        reset();
    }

    void reset() {
        pos = { FIELD_X + FIELD_W / 2.f, FIELD_Y + FIELD_H / 2.f };
        vel = { 0.f, 0.f };
        z  = 0.f;
        vz = 0.f;
    }

    void update(float dt) {
        // 2D position update
        pos += vel * dt;

        // Friction
        vel *= std::pow(BALL_FRICTION, dt * 60.f);

        // Z physics (ball can get bumped upward)
        if (z > 0.f || vz != 0.f) {
            vz -= GRAVITY * 0.5f * dt;   // ball is lighter feel
            z  += vz * dt;
            if (z <= 0.f) {
                z  = 0.f;
                vz = -vz * 0.4f;
                if (std::abs(vz) < 10.f) vz = 0.f;
            }
        }

        // Bounce off field walls
        if (pos.x - BALL_RADIUS < FIELD_X) {
            pos.x = FIELD_X + BALL_RADIUS;
            vel.x = std::abs(vel.x) * BALL_RESTITUTION;
        }
        if (pos.x + BALL_RADIUS > FIELD_RIGHT) {
            pos.x = FIELD_RIGHT - BALL_RADIUS;
            vel.x = -std::abs(vel.x) * BALL_RESTITUTION;
        }
        if (pos.y - BALL_RADIUS < FIELD_Y) {
            pos.y = FIELD_Y + BALL_RADIUS;
            vel.y = std::abs(vel.y) * BALL_RESTITUTION;
        }
        if (pos.y + BALL_RADIUS > FIELD_BOTTOM) {
            pos.y = FIELD_BOTTOM - BALL_RADIUS;
            vel.y = -std::abs(vel.y) * BALL_RESTITUTION;
        }
    }

    // Returns true if ball entered left goal
    bool inLeftGoal() const {
        return pos.x - BALL_RADIUS < FIELD_X &&
               pos.y > GOAL_Y && pos.y < GOAL_Y + GOAL_H;
    }

    // Returns true if ball entered right goal
    bool inRightGoal() const {
        return pos.x + BALL_RADIUS > FIELD_RIGHT &&
               pos.y > GOAL_Y && pos.y < GOAL_Y + GOAL_H;
    }

    void draw(sf::RenderTarget& rt) const {
        float drawRadius = BALL_RADIUS + z * 0.05f; // slight size change with height

        // Shadow on ground
        if (z > 0.f) {
            sf::CircleShape shadow(BALL_RADIUS * 0.9f);
            shadow.setOrigin(BALL_RADIUS * 0.9f, BALL_RADIUS * 0.9f);
            shadow.setPosition(pos);
            shadow.setFillColor({0, 0, 0, static_cast<sf::Uint8>(80 * (1.f - z / 150.f))});
            rt.draw(shadow);
        }

        // Glow
        sf::CircleShape glow(drawRadius + 6.f);
        glow.setOrigin(drawRadius + 6.f, drawRadius + 6.f);
        glow.setPosition(pos.x, pos.y - z);
        glow.setFillColor({200, 210, 255, 40});
        rt.draw(glow);

        // Ball body
        sf::CircleShape body(drawRadius);
        body.setOrigin(drawRadius, drawRadius);
        body.setPosition(pos.x, pos.y - z);
        body.setFillColor(Colors::BallColor);
        body.setOutlineThickness(2.f);
        body.setOutlineColor(Colors::BallOutline);
        rt.draw(body);

        // Hex pattern detail on ball
        sf::CircleShape detail(drawRadius * 0.55f);
        detail.setOrigin(drawRadius * 0.55f, drawRadius * 0.55f);
        detail.setPosition(pos.x, pos.y - z);
        detail.setFillColor({0,0,0,0});
        detail.setOutlineThickness(2.f);
        detail.setOutlineColor({150, 160, 180, 100});
        rt.draw(detail);
    }
};
