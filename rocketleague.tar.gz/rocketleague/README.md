# Rocket League — C++ / SFML Edition

A simplified Rocket League-inspired game written in modern C++17, using SFML 2.x for rendering and windowing. Featuring real-time physics, boost mechanics, AI opponent, particle effects, and a full neon Rocket League-style HUD.

---

## Screenshots

The game features:
- Dark neon field with glowing boost pads
- Two cars (Player WASD vs AI bot)
- Bouncing ball with momentum and wall physics
- Score/timer HUD, boost meters, minimap
- Goal celebrations with particle explosions

---

## Requirements

| Dependency | Version |
|------------|---------|
| C++ Compiler | GCC ≥ 9 or Clang ≥ 10 (C++17) |
| SFML | 2.5.x or 2.6.x |
| CMake (optional) | ≥ 3.14 |

---

## Build Instructions

### Option A — Makefile (simplest)

```bash
# 1. Install SFML
# Ubuntu/Debian:
sudo apt install libsfml-dev

# macOS (Homebrew):
brew install sfml

# 2. Build
make

# 3. Run
./rocket_league
# or:
make run
```

### Option B — CMake

```bash
# 1. Install SFML (see above)

# 2. Configure and build
mkdir build && cd build
cmake ..
cmake --build . --config Release

# 3. Run (binary is placed in project root)
cd ..
./rocket_league
```

### Option C — Single g++ command

```bash
g++ -std=c++17 -O2 -Isrc src/main.cpp \
    -lsfml-graphics -lsfml-window -lsfml-system \
    -o rocket_league
./rocket_league
```

### Windows (MSYS2 / MinGW)

```bash
pacman -S mingw-w64-x86_64-sfml
g++ -std=c++17 -O2 -Isrc src/main.cpp \
    -lsfml-graphics -lsfml-window -lsfml-system \
    -o rocket_league.exe
rocket_league.exe
```

### Windows (Visual Studio)

1. Download SFML 2.6 from https://sfml-dev.org
2. Create a new C++ Console App project
3. Add all `.hpp` files under `src/` and `src/main.cpp`
4. In Project Properties:
   - C/C++ → General → Additional Include Directories: `path\to\SFML\include;src`
   - Linker → General → Additional Library Directories: `path\to\SFML\lib`
   - Linker → Input → Additional Dependencies: `sfml-graphics.lib;sfml-window.lib;sfml-system.lib`
5. Copy SFML DLLs next to your `.exe`

---

## Controls

| Key | Action |
|-----|--------|
| `W` / `↑` | Accelerate forward |
| `S` / `↓` | Brake / reverse |
| `A` / `←` | Turn left |
| `D` / `→` | Turn right |
| `Shift` | Boost (burns boost meter) |
| `Space` | Jump |
| `C` | Toggle camera label (cosmetic) |
| `ESC` | Quit |
| `Enter` | Start match (from menu) |
| `R` | Return to menu (from game over) |

---

## Gameplay Rules

- **Match duration:** 3 minutes countdown
- **Scoring:** Hit the ball into the opponent's goal
- **Left goal (blue):** Orange team's target
- **Right goal (orange):** Blue team's target (you play Blue/Cyan)
- **Overtime:** If tied at time's end, play continues until next goal
- **Boost pads:** Collect glowing pads to refill your boost meter
  - Large pads (corners & sides): refill full boost, 10s respawn
  - Small pads: +25 boost, 4s respawn

---

## Architecture

```
rocketleague/
├── src/
│   ├── main.cpp         # Game loop, event handling, game states
│   ├── Constants.hpp    # All tuning values, colors, field dimensions
│   ├── Math.hpp         # Vector utilities (normalize, dot, length, clamp)
│   ├── Ball.hpp         # Ball physics, wall bouncing, goal detection, rendering
│   ├── Car.hpp          # Car physics, boost, jump, Z-axis, rendering + name tags
│   ├── Field.hpp        # Field drawing, goal rendering, boost pad struct
│   ├── HUD.hpp          # Score panel, timer, boost meters, minimap, goal splash
│   ├── Particles.hpp    # Particle system (boost trails, goal explosions, ball hits)
│   ├── AI.hpp           # Simple AI (chase ball, attack/defend decision)
│   └── Collision.hpp    # Circle-circle collision, ball-car impulse resolution
├── CMakeLists.txt       # CMake build
├── Makefile             # Simple make build
└── README.md            # This file
```

### Physics Summary

- **Cars:** Euler-integrated velocity with friction; turning scales with speed; boost multiplies acceleration cap; jump applies negative Z-velocity with gravity pulling back down.
- **Ball:** Separate X/Y (2D field) and Z (height) axes; wall bouncing with restitution coefficient; momentum conserved between hits.
- **Collision:** Cars and ball treated as circles for collision detection; impulse-based resolution with mass ratio (car = 3× ball); car velocity partially transferred to ball on hit.
- **Boost pads:** Axis-aligned circle proximity check; state tracks active/cooldown.

### AI Behavior

The bot uses a simple finite state machine with 10Hz decision updates:
1. **Attack mode** (ball on bot's half or attacking): Positions behind the ball along the vector from the player's goal → ball, then drives forward.
2. **Defend mode** (ball deep in opponent's half): Retreats toward its own goal and interposes between ball and goal.
The AI uses boost when far from target and in attack mode with >30 boost.

---

## Tuning

All game constants live in `src/Constants.hpp`. Notable ones:

| Constant | Default | Effect |
|----------|---------|--------|
| `CAR_SPEED` | 280 | Normal top speed (px/s) |
| `CAR_BOOST_SPEED` | 460 | Boosted top speed |
| `CAR_TURN_SPEED` | 200 | Degrees/second at full speed |
| `BALL_FRICTION` | 0.988 | Ball rolling resistance (per frame) |
| `BALL_RESTITUTION` | 0.75 | Bounciness off walls |
| `BOOST_DRAIN` | 33 | Boost % consumed per second |
| `MATCH_TIME` | 180 | Match duration in seconds |

---

## License

MIT — free to use, modify, and distribute.
